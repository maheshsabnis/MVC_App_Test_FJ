﻿using MVC_WebApp.Models;
using MVC_WebApp.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;

namespace MVC_WebApp.Controllers
{
    public class CategoryAPIController : ApiController
    {
        private readonly IRepository<Category, int> catRepo;

        public CategoryAPIController(IRepository<Category, int> catRepo)
        {
            this.catRepo = catRepo;
        }

        public IHttpActionResult Get()
        {
            var cats = catRepo.Get();
            var result = (from c in cats
                          select new Category()
                          {
                              CategoryRowId = c.CategoryRowId,
                              CategoryId = c.CategoryId,
                              CategoryName = c.CategoryName,
                              BasePrice = c.BasePrice
                          }).ToList();
            return Ok(result);
        }

        public IHttpActionResult Get(int id)
        {
            var cat = catRepo.Get(id);
            return Ok(cat);
        }


        public IHttpActionResult Post(Category cat)
        {
            if (ModelState.IsValid)
            {
                 cat = catRepo.Create(cat);
                return Ok(cat);
            }
            return BadRequest(ModelState);
        }
    }
}
