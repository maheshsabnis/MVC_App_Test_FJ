﻿
using MVC_WebApp.Models;
using MVC_WebApp.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_WebApp.Services
{
    /// <summary>
    /// Inject the DbContext as constructor injectation
    /// </summary>
    public class CategoryRepository : IRepository<Category, int>
    {
        private readonly MyAppDbContext ctx;
        public CategoryRepository(MyAppDbContext ctx)
        {
            this.ctx = ctx;
        }

        public Category Create(Category entity)
        {
            var res = ctx.Categories.Add(entity);
            ctx.SaveChanges();
            return res;
        }

        public bool Delete(int id)
        {
            var cat = ctx.Categories.Find(id);
            if (cat != null)
            {
                ctx.Categories.Remove(cat);
                ctx.SaveChanges();
                return true;
            }
            return false;
        }

        public IEnumerable<Category> Get()
        {
            return ctx.Categories.ToList();
        }

        public Category Get(int id)
        {
            return ctx.Categories.Find(id);
        }

        public bool Update(int id, Category entity)
        {
            var cat = ctx.Categories.Find(id);
            if (cat != null)
            {
                cat.CategoryId = entity.CategoryId;
                cat.CategoryName = entity.CategoryName;
                cat.BasePrice = entity.BasePrice;
                ctx.SaveChanges();
                return true;
            }
            return false;
        }
    }
}
