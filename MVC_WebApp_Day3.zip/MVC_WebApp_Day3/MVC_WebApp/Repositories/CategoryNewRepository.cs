﻿using MVC_WebApp.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Metadata.Edm;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Web;

namespace MVC_WebApp.Repositories
{
    public interface ICatDataAcess
    {
        List<Category> GetCats();
        Category GetCat(int id);
        Category CreateCat(Category cat);
        bool CheckCatExists(int id);
    }

    public class CategoryNewRepository : ICatDataAcess
    {
        MyAppDbContext ctx;
        public CategoryNewRepository()
        {
            ctx = new MyAppDbContext();
        }
        public bool CheckCatExists(int id)
        {
            var cat = ctx.Categories.Find(id);
            if (cat != null)
            {
                return true;
            }
            else 
            {
                return false;
            }
        }

        public Category CreateCat(Category cat)
        {
            cat = ctx.Categories.Add(cat);
            ctx.SaveChanges();
            return cat;
        }

        public Category GetCat(int id)
        {
            if (id <= 0)
                throw new Exception("id cannot be 0 or negative");
            var cat = ctx.Categories.Find(id);
            
            if (cat != null)
            {
                return cat;
            }
            else
            {
                return null;
            }
        }

        public List<Category> GetCats()
        {
            var cats = ctx.Categories.ToList();
            return cats;
        }
    }
}