﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MVC_WebApp.Controllers;
using MVC_WebApp.Models;

namespace MVC_New_TestProject
{
    [TestClass]
    public class CategoryNewControllerTest
    {
        [TestMethod]
        public void Index_Action_Method_Returns_Index_View_Test()
        {
            // create an instance of controller
            var controller = new CategoryNewController();

            // call the action method from the controller
            // Please install System.Web.Mcv for version 5.x
            var actualActionResult = controller.Index() as ViewResult;
            // check the response type
            //  Assert.IsInstanceOfType(actualActionResult, typeof(ViewResult));
            // check if the 'Index' view is returned by the method 
            Assert.AreEqual(actualActionResult.ViewName, "Index");
        }

        [TestMethod]
        public void Index_Action_Method_Returns_Index_View_With_Model_Test()
        {
            // create an instance of controller
            var controller = new CategoryNewController();

            // call the action method from the controller
            // Please install System.Web.Mcv for version 5.x
            var actualActionResult = controller.Index() as ViewResult;

            Assert.IsInstanceOfType(actualActionResult.Model, typeof(List<Category>)); ;
        }


        [TestMethod]
        public void Create_Action_Redirect_To_Index_Action()
        {
            // create an instance of controller
            var controller = new CategoryNewController();
            // Test Data
            var cat = new Category()
            {
                CategoryId = "Cat9001", CategoryName = "TestCat9001",
                BasePrice  =4000
            };

             RedirectToRouteResult result = controller.Create(cat)
                                             as RedirectToRouteResult;
            // please install System.Web assembly for RouteValues
            var expectedRouteValue = result.RouteValues["action"].ToString(); 

            Assert.AreEqual(expectedRouteValue, "Index");
        }


        [TestMethod]
        public void Create_Action_Redirect_To_Error_View_For_Invalid_ModelState_Test()
        {
            // create an instance of controller
            var controller = new CategoryNewController();

            // define the validation rule
            controller.ModelState.AddModelError("CategoryName", "Required");

            // Test Data
            var cat = new Category()
            {
                CategoryId = "Cat9001",
                BasePrice = 4000
            };

            ViewResult result = controller.Create(cat)
                                            as ViewResult;

            Assert.AreEqual(result.ViewName, "Error");
        }

    }
}
