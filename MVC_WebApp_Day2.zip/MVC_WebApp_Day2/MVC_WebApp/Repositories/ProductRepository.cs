﻿using MVC_WebApp.Models;
using MVC_WebApp.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_WebApp.Services
{
    public class ProductRepository : IRepository<Product, int>
    {
        private readonly MyAppDbContext ctx;

        public ProductRepository(MyAppDbContext ctx)
        {
            this.ctx = ctx; // the ctx that is injected from DI
        }

        public Product Create(Product entity)
        {
            var res = ctx.Products.Add(entity);
            ctx.SaveChanges();
            return res;
        }

        public bool Delete(int id)
        {
            var prd = ctx.Products.Find(id);
            if (prd != null)
            {
                ctx.Products.Remove(prd);
                ctx.SaveChanges();
                return true;
            }
            return false;
        }

        public IEnumerable<Product> Get()
        {
            return ctx.Products.ToList();
        }

        public Product Get(int id)
        {
            return ctx.Products.Find(id);
        }

        public bool Update(int id, Product entity)
        {
            var prd = ctx.Products.Find(id);
            if (prd != null)
            {
                prd.ProductId = entity.ProductId;
                prd.ProductName = entity.ProductName;
                prd.Manufacturer = entity.Manufacturer;
                prd.Price = entity.Price;
                ctx.SaveChanges();
                return true;
            }
            return false;
        }
    }
}
