﻿using MVC_WebApp.Models;
using MVC_WebApp.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;
using System.Web.Mvc;

namespace MVC_WebApp.Controllers
{
    public class ProductController : Controller
    {
        private readonly IRepository<Product, int> prdRepo;
        private readonly IRepository<Category, int> catRepo;

        public ProductController(IRepository<Product, int> prdRepo, IRepository<Category, int> catRepo)
        {
            this.prdRepo = prdRepo;
            this.catRepo = catRepo;
        }

        // GET: Product
        public ActionResult Index()
        {
            var prds = prdRepo.Get();
            return View(prds);
        }


        public ActionResult Create()
        {
            var prd = new Product();
            ViewBag.CategoryRowId = new SelectList(catRepo.Get(), "CategoryRowId", "CategoryName");
            return View(prd);
        }

        [HttpPost]
        public ActionResult Create(Product prd)
        {
            if (ModelState.IsValid)
            {
                prd = prdRepo.Create(prd);
                return RedirectToAction("Index");
            }
            return View(prd);
        }

        public ActionResult Edit(int id)
        {
            var prd = prdRepo.Get(id);
            return View(prd);
        }

        [HttpPost]
        public ActionResult Edit(int id,Product prd)
        {
            if (ModelState.IsValid)
            {
                var res = prdRepo.Update(id,prd);
                if (res)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            return View(prd);
        }

        public ActionResult Delete(int id)
        {
            var prd = prdRepo.Delete(id);
            return RedirectToAction("Index");
        }
    }
}